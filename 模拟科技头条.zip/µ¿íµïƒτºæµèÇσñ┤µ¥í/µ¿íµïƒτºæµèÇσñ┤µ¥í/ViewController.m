//
//  ViewController.m
//  模拟科技头条
//
//  Created by mac on 16/8/26.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "ViewController.h"
#import "AppModel.h"
#import "AppTableViewCell.h"
@interface ViewController ()<UITableViewDataSource>
{
    NSArray *_groupList;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.tableView.estimatedRowHeight = 80;
//    self.tableView.rowHeight = UITableViewAutomaticDimension;
//    self.tableView.rowHeight = 80;
    [self loadJsonData];
    
}
-(void)loadJsonData
{
    NSURL *url = [NSURL URLWithString:@"http://news.coolban.com/Api/Index/news_list/app/2/cat/0/limit/20/time/1472031475/type/0?channel=appstore&uuid=1CF3D8F1-1DFA-4F0B-8335-40F209B0E355&net=5&model=iPhone&ver=1.0.5"];
    [[[NSURLSession sharedSession]dataTaskWithURL:url completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        if (error == nil && data != nil) {
            id resqult = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
            //NSLog(@"%@,%@",resqult,[resqult class]);
            NSMutableArray *arrayM = [NSMutableArray array];
            [resqult enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                AppModel *model = [AppModel appModelWithDict:obj];
                [arrayM addObject:model];
            }];
            _groupList = arrayM.copy;
            [[NSOperationQueue mainQueue]addOperationWithBlock:^{
                
               [self.tableView reloadData];
                
            }];
        }else
        {
            NSLog(@"%@",error);
        }
    }]resume];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _groupList.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    AppTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellID" forIndexPath:indexPath];
    AppModel *model = _groupList[indexPath.row];
    cell.model = model;
//    cell.textLabel.text = model.title;
//    cell.detailTextLabel.text = model.sitename;
    return cell;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
