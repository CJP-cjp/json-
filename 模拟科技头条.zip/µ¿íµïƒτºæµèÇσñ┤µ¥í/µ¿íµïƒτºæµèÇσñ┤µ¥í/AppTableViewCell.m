//
//  AppTableViewCell.m
//  模拟科技头条
//
//  Created by mac on 16/8/26.
//  Copyright © 2016年 mac. All rights reserved.
//

#import "AppTableViewCell.h"
#import "Masonry.h"
#import "UIImageView+WebCache.h"
@interface AppTableViewCell()
@property(weak,nonatomic)UILabel *topLabel;
@property(weak,nonatomic)UILabel *leftLabel;
@property(weak,nonatomic)UIImageView *imageV;
@property(weak,nonatomic)UILabel *rightLabel;
@end
@implementation AppTableViewCell

- (void)awakeFromNib {
    // Initialization code
    [self setupUI];

}
//-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
//{
//    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
//        [self setupUI];
//    }
//    return self;
//    
//}
-(void)setupUI
{
    UILabel *topLabel = [[UILabel alloc]init];
    topLabel.numberOfLines = 0;
    topLabel.font = [UIFont systemFontOfSize:13 ];
    topLabel.text = @"fewrty基地及管理费就是垃圾费 否方法否否否 过分了点击诶";
    [topLabel sizeToFit];
    [self.contentView addSubview:topLabel];
    self.topLabel = topLabel;
    
    UILabel *leftLabel = [[UILabel alloc]init];
    leftLabel.text = @"新浪科技";
    [leftLabel sizeToFit];
    leftLabel.font = [UIFont systemFontOfSize:10];
    leftLabel.textAlignment = NSTextAlignmentJustified;
    [self.contentView addSubview:leftLabel];
    self.leftLabel = leftLabel;
    
    UIImageView *imageView = [[UIImageView alloc]init];
    imageView.backgroundColor = [UIColor greenColor];
//    [imageView sd_setImageWithURL:[NSURL URLWithString:@"http://n.sinaimg.cn/tech/transform/20160826/nt6N-fxvixet4007881.jpg"]];
    imageView.image = [UIImage imageNamed:@"hm"];
    //[imageView sizeToFit];
    [self.contentView addSubview:imageView];
    self.imageV = imageView;
    
    UILabel *rightLabel = [[UILabel alloc]init];
    rightLabel.font = [UIFont systemFontOfSize:12];
        rightLabel.text =@"1472214486";
    [rightLabel sizeToFit];
    [self.contentView addSubview:rightLabel];
    self.rightLabel = rightLabel;
    
    [topLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(260);
        //make.height.mas_equalTo(40);
        make.top.equalTo(self.contentView);
        make.left.equalTo(self.contentView).offset(10);
    }];
    [leftLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(topLabel);
        make.top.equalTo(topLabel.mas_bottom).offset(10);
//        make.height.mas_equalTo(15);
//        make.width.mas_equalTo(100);
    }];
    
    [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(topLabel);
        make.right.equalTo(self.contentView).offset(-10);
       make.height.mas_equalTo(30);
        make.width.mas_equalTo(70);
    }];
    [rightLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(imageView);
        make.bottom.equalTo(self.contentView).offset(-10);
       // make.baseline.equalTo(leftLabel);
//        make.height.mas_equalTo(30);
//        make.width.mas_equalTo(80);
    }];
//    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.bottom.equalTo(leftLabel.mas_bottom).offset(10);
//        make.size.equalTo(self);
//    }];
    
}
-(void)setModel:(AppModel *)model
{
    _model = model;
    self.topLabel.text = model.title;
    self.leftLabel.text = model.sitename;
    self.rightLabel.text = model.addtime;
    NSLog(@"%@",[NSThread currentThread]);
    [self.imageView sd_setImageWithURL:[NSURL URLWithString:model.src_img]];
   // [self.imageView sd_setImageWithURL:[NSURL URLWithString:model.src_img] placeholderImage:nil options:SDWebImageAllowInvalidSSLCertificates];
    
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
