//
//  NSArray+Log.h
//  07-数组或字典输出中文编码的问题
//
//  Created by zhangjie on 16/8/22.
//  Copyright © 2016年 zhangjie. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (Log)

@end

@interface NSDictionary (Log)

@end
