//
//  AppTableViewCell.h
//  模拟科技头条
//
//  Created by mac on 16/8/26.
//  Copyright © 2016年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppModel.h"
@interface AppTableViewCell : UITableViewCell
@property(strong,nonatomic)AppModel *model;
@end
